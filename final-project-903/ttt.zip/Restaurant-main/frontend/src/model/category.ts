export class Category {
  id:Number;
  name:String;
  logo:String;
  flag:String;
}
