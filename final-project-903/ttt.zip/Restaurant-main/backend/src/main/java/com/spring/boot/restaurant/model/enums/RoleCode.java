package com.spring.boot.restaurant.model.enums;

public enum RoleCode {
    ADMIN,
    USER
}
